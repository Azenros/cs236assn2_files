drop table if exists Authored;
drop table if exists Author;
drop table if exists Article;
drop table if exists Book;
drop table if exists Incollection;
drop table if exists Inproceddings;
drop table if exists Publication;

create table Author (
    id numeric(9)    primary key,
    aname text       not null,
    homepage text    not null
);

create table Publication (
    pubid int        primary key,
    pubkey text      not null unique,
    title text,
    year int
);

create table Authored (
    id numeric(9),
    pubid int,
    foreign key(id) references Author(id),
    foreign key(pubid) references Publication(pubid)
);

create table Article (
    pubid int        not null,
    journal text,
    number int,
    month int,
    volume int,
    foreign key(pubid) references Publication(pubid)
);

create table Book (
    pubid int        not null,
    isbn text        unique,
    publisher text,  
    foreign key(pubid) references Publication(pubid)
);

create table Incollection (
    pubid int        not null,
    isbn text        unique,
    booktitle text,
    publisher text,
    foreign key(pubid) references Publication(pubid)
);

create table Inproceddings (
    pubid int        not null,
    booktitle text,
    editor text,
    foreign key(pubid) references Publication(pubid)
)